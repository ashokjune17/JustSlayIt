import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  images: string[] = [
    '/assets/frt-img-teeth.png',
    '/assets/sec-img-teeth.png',
    '/assets/three-img-teeth.png',
    '/assets/fourth-img-teeth.png',
    '/assets/fifth-img-teeth.png'
  ];
  currentStartIndex: number = -1;
  currentImageSet = [];
  medicalTeamAccordion = [
    {
      accordionHeader: "Experience",
      accordionIcon:"/assets/experience.png",
      accordionContent:"At Slay, we bring together leading orthodontists, digital smile designers, and dental innovators to craft aligners that are both effective and effortless. Backed by years of expertise in dental technology, our team ensures that every smile transformation is seamless, precise, and tailored to you."
    },
    {
      accordionHeader: "Safety",
      accordionIcon:"/assets/safety.png",
      accordionContent:"Slay Aligners are made using FDA-approved, CE-certified Graphy materials, ensuring biocompatibility and safety. Rigorously tested under ISO 10993 and Class II Medical Device Standards, they are BPA-free, durable, and gentle on your teeth."
    },
    {
      accordionHeader: "Monitoring",
      accordionIcon:"/assets/monitoring.png",
      accordionContent:"Stay on track with your smile transformation journey through smart treatment monitoring. Our expert team is always available for virtual check-ins, treatment progress evaluations, and personalized guidance, so you never feel alone in the process. Your perfect smile is always within reach."
    },
    {
      accordionHeader: "Excellence",
      accordionIcon:"/assets/excellence.png",
      accordionContent:"From cutting-edge 3D printing technology to precision-driven treatment planning, we set the bar high. Every aligner is designed for maximum comfort, durability, and effectiveness, ensuring that your journey to the perfect smile is nothing short of extraordinary."
    },
  ]
  faqSet = [
    {
      question:"What makes Slay different?",
      answer:"Slay Aligners use Shape Memory Aligner (SMA) technology, applying a gentle, continuous force for faster and more comfortable treatment—no attachments needed. Made from FDA & CE-certified Graphy materials, they are heat-activated for a perfect fit and require fewer clinic visits than traditional aligners."
    },
    {
      question:"What makes Slay different?",
      answer:"Slay Aligners use patented Shape Memory Technology, providing consistent force without losing shape—unlike traditional aligners. With no bulky attachments, enhanced comfort, and faster treatment, they offer a stronger, more aesthetic, and durable solution for your perfect smile."
    },
    {
      question:"What is different between Slay Clear Aligner treatment and traditional orthodontic treatment?",
      answer:"Slay Aligners are clear, removable, and virtually invisible, unlike metal brackets and wires. They provide gentle, pain-free movement, allow normal brushing and flossing, and offer more flexibility since they can be removed for eating and special occasions."
    },
    {
      question:"Who can have a Slay orthodontic treatment?",
      answer:"Slay Aligners are designed for teens and adults seeking a discreet, comfortable, and effective way to correct dental misalignment. Our Shape Memory Aligners (SMA) can treat various cases, from crowding and spacing to bite issues, under the guidance of expert orthodontists. At Slay, we start with a detailed digital scan and consultation, where our orthodontists assess your case and create a customized treatment plan tailored to your needs."
    },
    {
      question:"When can I start treatment with Slay?",
      answer:"The best time to start your Slay Aligner journey is now! Begin by booking a free digital scan at a Slay clinic near you. Our specialists will analyze your case, create a precise treatment plan, and get your aligners ready in no time. The sooner you start, the sooner you’ll be smiling with confidence!"
    }
  ];

  activeAccordionIndex = 0;
  activeFaqIndex = 0;
  constructor() { }

  ngOnInit(): void {
    this.next()
  }


  prev() {
    this.currentStartIndex -= 1;
    this.currentImageSet = this.images.slice(this.currentStartIndex, this.currentStartIndex + 2);
  }

  next() {
    this.currentStartIndex += 1;
    this.currentImageSet = this.images.slice(this.currentStartIndex, this.currentStartIndex + 3);
  }
  openAccordion(index:any)
  {
    this.activeAccordionIndex = index;
  }
  openFaq(index:any)
  {
    this.activeFaqIndex = index;
  }
}
